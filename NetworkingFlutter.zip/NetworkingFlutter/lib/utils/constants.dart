

class Constants {

//    static final String HEADLINE_NEWS_URL = 'https://newsapi.org/v2/top-headlines?country=us&apiKey=04c245ed3319422b8d49ae0495b3f123';
    static final String HEADLINE_NEWS_URL = 'http://newsapi.org/v2/everything?q="ListView.builder"&from=2020-01-01&sortBy=popularity&apiKey=04c245ed3319422b8d49ae0495b3f123';

    static final String NEWS_PLACEHOLDER_IMAGE_ASSET_URL = 'assets/placeholder.png';

}